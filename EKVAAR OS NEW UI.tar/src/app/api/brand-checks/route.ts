import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET() {
  const checks = await db.brandCheck.findMany({ orderBy: { checkedAt: 'desc' }, take: 50 })
  return NextResponse.json(checks)
}
